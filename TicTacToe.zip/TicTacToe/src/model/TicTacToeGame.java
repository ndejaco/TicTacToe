package model;

import static org.junit.Assert.assertTrue;

import java.awt.Point;

/**
 * 
 * A fully-functional model of a Tic-Tac-Toe (Noughts and Crosses) game. You
 * will need to use this model, and should not need to change it.
 * 
 * @author Mercer
 * 
 */
public class TicTacToeGame extends OurObservable {
	private char[][] board;
	private char nextChar;
	private int moveNumber;
	private int size;
	private ComputerPlayer computerPlayer;

	public TicTacToeGame() {
		size = 3;
		initializeBoard();
	}

	public void startNewGame() {
		initializeBoard();
		// The state of this mode just changed
		notifyObservers();
	}

	public void setComputerPlayer(ComputerPlayer computerPlayer) {
		this.computerPlayer = computerPlayer;
	}

	public ComputerPlayer getComputerPlayer() {
		return computerPlayer;
	}

	private void initializeBoard() {
		board = new char[size][size];
		for (int r = 0; r < size; r++)
			for (int c = 0; c < size; c++)
				board[r][c] = '_';
		moveNumber = 0;
	}

	// Precondition row and col are both in the range of 0 through 2
	public boolean choose(int row, int col) {
		if (board[row][col] != '_')
			return false;
		else {
			if (moveNumber % 2 == 0)
				nextChar = 'X';
			else
				nextChar = 'O';
			board[row][col] = nextChar;
			moveNumber++;
			notifyObservers();
			return true;
		}
	}

	@Override
	public String toString() {
		String result = "";
		for (int r = 0; r < size; r++) {
			for (int c = 0; c < size; c++)
				result += " " + board[r][c] + " ";
			result += "\n";
		}
		return result;
	}

	public char[][] getTicTacToeBoard() {
		return board;
	}

	public boolean didWin(char playerChar) {
		return wonByRow(playerChar) || wonByCol(playerChar)
				|| wonByDiagonal(playerChar);
	}

	private boolean wonByRow(char playerChar) {
		for (int r = 0; r < size; r++) {
			int rowSum = 0;
			for (int c = 0; c < size; c++)
				if (board[r][c] == playerChar)
					rowSum++;
			if (rowSum == size)
				return true;
		}
		return false;
	}

	private boolean wonByCol(char playerChar) {
		for (int c = 0; c < size; c++) {
			int colSum = 0;
			for (int r = 0; r < size; r++)
				if (board[r][c] == playerChar)
					colSum++;
			if (colSum == size)
				return true;
		}
		return false;
	}

	private boolean wonByDiagonal(char playerChar) {
		// Check Diagonal from upper left to lower right
		int sum = 0;
		for (int r = 0; r < size; r++)
			if (board[r][r] == playerChar)
				sum++;
		if (sum == size)
			return true;

		// Check Diagonal from upper right to lower left
		sum = 0;
		for (int r = size - 1; r >= 0; r--)
			if (board[size - r - 1][r] == playerChar)
				sum++;
		if (sum == size)
			return true;

		// No win on either diagonal
		return false;
	}

	public boolean tied() {
		return maxMovesRemaining() == 0 && !didWin('X') && !didWin('O');
	}

	public int maxMovesRemaining() {
		int result = 0;
		for (int r = 0; r < size; r++)
			for (int c = 0; c < size; c++)
				if (board[r][c] == '_')
					result++;
		return result;
	}

	public int size() {
		return size;
	}

	public boolean available(int r, int c) {
		return board[r][c] == '_';
	}

	public boolean stillRunning() {
		return !tied() && !didWin('X') && !didWin('O');
	}

	public String getBattle() {
		ComputerPlayer random = new ComputerPlayer("Random");
		random.setStrategy(new RandomAI());
		ComputerPlayer AStopper = new ComputerPlayer("Random Two");
		AStopper.setStrategy(new Stopper());

		int randomWins = 0;
		int intermediateWins = 0;
		int ties = 0;

		for (int game = 1; game <= 500; game++) {
			char winner = playOneGame(AStopper, random);
			if (winner == 'X')
				intermediateWins++;
			if (winner == 'O')
				randomWins++;
			if (winner == 'T')
				ties++;
		}

		for (int game = 1; game <= 500; game++) {
			char winner = playOneGame(random, AStopper);
			if (winner == 'X')
				randomWins++;
			if (winner == 'O')
				intermediateWins++;
			if (winner == 'T')
				ties++;
		}

		return "RandomAI wins: " + randomWins + "\nStopper Wins: "
				+ intermediateWins + "\nTies: " + ties;

	}

	private char playOneGame(ComputerPlayer first, ComputerPlayer second) {
		TicTacToeGame theGame = new TicTacToeGame();

		while (true) {
			Point firstsMove = first.desiredMove(theGame);
			assertTrue(theGame.choose(firstsMove.x, firstsMove.y));

			if (theGame.tied())
				return 'T';

			if (theGame.didWin('X'))
				return 'X';
			if (theGame.didWin('O'))
				return 'O';

			Point secondsMove = second.desiredMove(theGame);
			assertTrue(theGame.choose(secondsMove.x, secondsMove.y));

			if (theGame.tied())
				return 'T';

			if (theGame.didWin('X'))
				return 'X';
			if (theGame.didWin('O'))
				return 'O';
		}
	}
}
