package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import model.ComputerPlayer;
import model.RandomAI;
import model.Stopper;
import model.TicTacToeGame;

/**
 * Allows the user to play TicTacToe against the computer.
 * 
 * When you are done with this class, it will have different AIs to play
 * against, different views to see the game through, the ability to start a new
 * game, and the ability to run a tournament, all available as options in the
 * JMenu.
 * 
 * @author mercer
 */
public class TicTacToeGUI extends JFrame {

	public static void main(String[] args) {
		TicTacToeGUI g = new TicTacToeGUI();
		g.setVisible(true);
	}
    
	private JFrame aFrame;
	private TicTacToeGame theGame;
	private JPanel currentView;
	private GraphicalView graphicalView;
	private ButtonView buttonView;
	private boolean graphical = false;
	private ComputerPlayer computerPlayer;

	// TODO Add another view

	public static final int width = 300;
	public static final int height = 360;

	public TicTacToeGUI() {
 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(width, height);
		this.setLocation(100, 40);
		this.setTitle("Tic Tac Toe");
		initializeGameForTheFirstTime();
		setupMenus();
		currentView = new JPanel();
		graphicalView = new GraphicalView(theGame,width,height);
		buttonView = new ButtonView(theGame, width, height);
		setViewTo(buttonView);
		addObservers();
		add(graphicalView);
	}

	private void addObservers() {
			theGame.addObserver(graphicalView);
			theGame.addObserver(buttonView);
		
	}

	public void initializeGameForTheFirstTime() {
		theGame = new TicTacToeGame();
		// This event driven program will always have
		// a computer player who takes the second turn
	    computerPlayer = new ComputerPlayer("Random Player");
		computerPlayer.setStrategy(new RandomAI());
		theGame.setComputerPlayer(computerPlayer);
	}
	
	public void setViewTo(JPanel aView) {
		theGame.notifyObservers();
	}
	
	

	private void setupMenus() {
		JMenuItem menu = new JMenu("Options");
		JMenuItem newGame = new JMenuItem("New Game");
		JMenuItem jmi1Nest = new JMenu("Views");
		JMenuItem jmi2Nest = new JMenu("Strategy");
		JMenuItem battle = new JMenuItem("Battle");
		menu.add(newGame);
		menu.add(jmi1Nest);
		menu.add(jmi2Nest);
		menu.add(battle);
		JMenuItem button = new JMenuItem("Button");
		JMenuItem graphical = new JMenuItem("Graphical");
		JMenuItem randomButton = new JMenuItem("Random AI");
		JMenuItem stopperButton = new JMenuItem("Stopper");

		jmi1Nest.add(button);
		jmi1Nest.add(graphical);
		jmi2Nest.add(randomButton);
		jmi2Nest.add(stopperButton);
		// TODO Add menu selections

		// Set the menu bar
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		menuBar.add(menu);

		// Add the same listener to all menu items requiring action
		MenuItemListener menuListener = new MenuItemListener();
		newGame.addActionListener(menuListener);
		button.addActionListener(menuListener);
		graphical.addActionListener(menuListener);
		randomButton.addActionListener(menuListener);
		stopperButton.addActionListener(menuListener);
		battle.addActionListener(menuListener);

		// TODO Add listeners
	}

	private class MenuItemListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String text = ((JMenuItem) e.getSource()).getText();

			// TODO: Correctly respond to Menu Selections
		;
			if (text.equals("Button"))
				setViewTo(buttonView);
			if (text.equals("Graphical")) {
				graphical = true;
				addObservers();
				setViewTo(graphicalView);
			}
			if (text.equals("New Game"))
				theGame.startNewGame();
			if (text.equals("Random AI"))
				computerPlayer.setStrategy(new RandomAI());
			if (text.equals("Stopper"))
				computerPlayer.setStrategy(new Stopper());
			if (text.equals("Battle"))
				JOptionPane.showMessageDialog(null,
						theGame.getBattle());
		}
	}
}