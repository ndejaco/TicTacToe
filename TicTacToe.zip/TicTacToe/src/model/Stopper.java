package model;

import java.awt.Point;
import java.util.Random;

public class Stopper implements TicTacToeStrategy {
	private char[][] theBoard;
	private TicTacToeGame theGame;
	private static Random generator;

	public Stopper() {
		generator = new Random();
	}

	@Override
	public Point desiredMove(TicTacToeGame aGame) {
		boolean set = false;
		theGame = aGame;
		theBoard = theGame.getTicTacToeBoard();
		
		while (!set) {
		      if (theGame.maxMovesRemaining() == 0) {
		        throw new IGotNowhereToGoException(
		            " -- Hey there programmer, the board is filled");
		      }
		      
		       if (getWinOrBlock('O') != null) {
		    	   set = true;
		    	   return getWinOrBlock('O');
		       }
		       
		       else if (getWinOrBlock('X') != null) {
		    	   set = true;
		    	   return getWinOrBlock('X');
		       }
		        
		       else {
		    	   if (theGame.available(1, 1)) {
		    		   set = true;
		    		   return new Point(1, 1);
		    	   }
		    	   
		    	   for (int r = 0; r < 3; r++) {
		    		   for (int c = 0; c < 3; c++) {
		    			   if (isCorner(r, c) && theGame.available(r,c)) {
		    				   set = true;
			    		       return new Point(r, c);
		    			   }
		    			   
		    		   }
		    	   }
		    	   
		    	   int row = generator.nextInt(3);
		    	      int col = generator.nextInt(theGame.size());
		    	      if (theGame.available(row, col)) {
		    	        set = true;
		    	        return new Point(row, col);
		    	      }
		       }
		       
		       
		        
		}
		
		return null;
		      
		      
		            	
		      
	}

	private Point getWinOrBlock(char playerCharacter) {
		boolean set = false;
		for (int r = 0; r < 3; r++) {
			int rowSum = 0;
			for (int c = 0; c < 3; c++) {
				if (theBoard[r][c] == playerCharacter)
					rowSum++;
				if (rowSum == 2) {
					for (int i = 0; i < 3; i++) {
						if (theGame.available(r, i)) {
							set = true;
							return new Point(r, i);
						}
					}
				}
			}
		}

		for (int c = 0; c < 3; c++) {
			int colSum = 0;
			for (int r = 0; r < 3; r++) {
				if (theBoard[r][c] == playerCharacter)
					colSum++;
				if (colSum == 2) {
					for (int i = 0; i < 3; i++) {
						if (theGame.available(i, c)) {
							set = true;
							return new Point(i, c);
						}
					}
				}
			}
		}

		int sum = 0;
		for (int r = 0; r < 3; r++)
			if (theBoard[r][r] == playerCharacter)
				sum++;
		if (sum == 2) {
			for (int i = 0; i < 3; i++) {
				if (theGame.available(i, i)) {
					set = true;
					return new Point(i, i);
				}
			}
		}
		return null;
	}
	
	private boolean isCorner(int r, int c) {
		if ((r == 0 && (c == 0 || c == 2)) || (r == 2 && (c == 0 || c == 2)))
			return true;
		return false;
		
	}

}
