package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import model.ComputerPlayer;
import model.OurObserver;
import model.TicTacToeGame;

public class GraphicalView extends JPanel implements OurObserver {
	private TicTacToeGame theGame;
	private ComputerPlayer computerPlayer;
	private int height, width;
	private int xIndex, yIndex;
	private boolean paint = false;
	private char[][] theGrid;

	public GraphicalView(TicTacToeGame TicTacToeGame, int width, int height) {
		theGame = TicTacToeGame;
		theGrid = theGame.getTicTacToeBoard();
		this.height = height;
		this.width = width;
		computerPlayer = theGame.getComputerPlayer();
		initializeGraphicalPanel();
		int size = theGame.size();
		this.setLayout(null);
		ClickListener clickListener = new ClickListener();
		this.addMouseListener(clickListener);
	}

	private void initializeGraphicalPanel() {
		JPanel graphicalPanel = new JPanel();
		int size = theGame.size();
		graphicalPanel.setLayout(null);
		ClickListener clickListener = new ClickListener();
		graphicalPanel.addMouseListener(clickListener);

	}

	public void paintComponent(Graphics g) {
		g.drawLine(100, 360, 100, 0);
		g.drawLine(200, 360, 200, 0);
		g.drawLine(0, 100, 300, 100);
		g.drawLine(0, 200, 300, 200);
	}

	@Override
	public void update() {
		if (theGame.maxMovesRemaining() == theGame.size() * theGame.size()) {
			resetCells(true);
		}
		if (!theGame.stillRunning()) {
			resetCells(false);
		}
		else {
			updateCells();
		}
	}

	private void resetCells(boolean b) {
		Graphics g = getGraphics();
		Graphics2D g2 = (Graphics2D) g;
		initializeGraphicalPanel();
	}
		


	private void updateCells() {
		Graphics g = getGraphics();
		Graphics2D g2 = (Graphics2D) g;
		char[][] temp = theGame.getTicTacToeBoard();
		for (int i = 0; i < temp.length; i++) {
			for (int j = 0; j < temp[i].length; j++) {
				String text = "" + temp[i][j];
				if (text.equals("X") || text.equals("O")) {
					g2.setFont(new Font("Arial", Font.BOLD, 40));
					if (text.equals("X"))
						g2.setColor(Color.RED);
					if (text.equals("O"))
						g2.setColor(Color.BLUE);
					g2.drawString(text, (50 + (100 * i)), (50 + (100 * j)));

				}
			}
		}
	}

	public void setXAndY(int x, int y) {
		xIndex = x;
		yIndex = y;
	}

	private class ClickListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
			Graphics g = getGraphics();
			Graphics2D g2 = (Graphics2D) g;
			int xCoord = e.getX();
			int yCoord = e.getY();
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					if (xCoord >= (100 * i) && xCoord <= (100 * (i + 1))
							&& yCoord >= (100 * j) && yCoord <= (100 * (j + 1))) {
						theGame.choose(i, j);
						setXAndY(i, j);
					}
				}
			}

			if (theGame.tied()) {
				g2.setFont(new Font("Arial", Font.PLAIN, 70));
				g2.drawString("Tied", 0, 120);
				updateCells();

			} else if (theGame.didWin('X')) {
				g2.setFont(new Font("Arial", Font.PLAIN, 70));
				g2.drawString("X Wins!", 0, 120);
				updateCells();
			} else {
				// If the game is not over, let the computer player choose
				// This algorithm assumes the computer player always
				// goes after the human player and is represented by 'O', not
				// 'X'
				Point play = computerPlayer.desiredMove(theGame);
				theGame.choose(play.x, play.y);
				if (theGame.didWin('O')) {
					g2.setFont(new Font("Arial", Font.PLAIN, 70));
					g2.drawString("O Wins!", 0, 120);
					updateCells();
				}
			}

		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}
	}
}